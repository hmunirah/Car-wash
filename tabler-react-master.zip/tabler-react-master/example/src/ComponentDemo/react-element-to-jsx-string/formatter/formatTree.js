Object.defineProperty(exports, "__esModule", {
  value: true,
});

var _formatTreeNode = require("./formatTreeNode");

var _formatTreeNode2 = _interopRequireDefault(_formatTreeNode);

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}

exports.default = function(node, options) {
  return (0, _formatTreeNode2.default)(node, false, 0, options);
};
//# sourceMappingURL=formatTree.js.map
