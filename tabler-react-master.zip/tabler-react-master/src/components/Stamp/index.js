// @flow

import Stamp from "./Stamp.react";

export { Stamp as default };
