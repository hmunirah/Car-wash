// @flow

import Tooltip from "./Tooltip.react";

export { Tooltip as default };
