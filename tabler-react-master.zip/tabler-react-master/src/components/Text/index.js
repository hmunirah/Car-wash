// @flow

import Text from "./Text.react";

export { Text as default };
