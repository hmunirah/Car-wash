// @flow

import StoreCard from "./StoreCard.react";

export { StoreCard as default };
