// @flow

import ContactCard from "./ContactCard.react";

export { ContactCard as default };
