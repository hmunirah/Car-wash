// @flow

import ProgressCard from "./ProgressCard.react";

export { ProgressCard as default };
