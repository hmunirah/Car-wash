// @flow

import GalleryCard from "./GalleryCard.react";

export { GalleryCard as default };
