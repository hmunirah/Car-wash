// @flow

import Comment from "./Comment.react";

export { Comment as default };
