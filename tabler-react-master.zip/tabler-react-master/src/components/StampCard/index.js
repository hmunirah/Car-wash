// @flow

import StampCard from "./StampCard.react";

export { StampCard as default };
