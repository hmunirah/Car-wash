```jsx
  <Badge color="primary" className="mr-1">
    primary
  </Badge>
  <Badge color="secondary" className="mr-1">
    secondary
  </Badge>
  <Badge color="info" className="mr-1">
    info
  </Badge>
  <Badge color="warning" className="mr-1">
    warning
  </Badge>
  <Badge color="success" className="mr-1">
    success
  </Badge>
  <Badge color="danger" className="mr-1">
    danger
  </Badge>
```
