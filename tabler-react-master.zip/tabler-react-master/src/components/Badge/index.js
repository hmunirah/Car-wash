// @flow

import Badge from "./Badge.react";

export { Badge as default };
