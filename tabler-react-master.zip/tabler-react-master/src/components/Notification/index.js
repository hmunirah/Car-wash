// @flow

import Notification from "./Notification.react";
import type Props from "./Notification.react";

export { Notification as default };
export type { Props as NotificationProps };
