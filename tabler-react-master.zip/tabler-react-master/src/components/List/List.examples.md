```jsx
<List>
  <List.Item>An Item</List.Item>
  <List.Item>Another Item</List.Item>
  <List.Item>A third item</List.Item>
</List>
```

#### Unstyled

```jsx
<List unstyled>
  <List.Item>An Item</List.Item>
  <List.Item>Another Item</List.Item>
  <List.Item>A third item</List.Item>
</List>
```
