// @flow

import Card from "./Card.react";

export { Card as default };
