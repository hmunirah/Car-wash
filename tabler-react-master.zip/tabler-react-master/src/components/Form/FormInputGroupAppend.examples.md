```jsx
<Form.InputGroup>
    <Form.Input placeholder="Search for..." />
    <Form.InputGroupAppend>
    <Button
        RootComponent="a"
        color="primary"
        href="http://www.google.com"
    >
        Go!
    </Button>
    </Form.InputGroupAppend>
</Form.InputGroup>
```