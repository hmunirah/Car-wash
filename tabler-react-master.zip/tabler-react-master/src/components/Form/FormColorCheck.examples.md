### Color input

```jsx
<Form.Group label="Color input">
  <Form.ColorCheck>
    <Form.ColorCheckItem color="azure" />
    <Form.ColorCheckItem color="indigo" />
    <Form.ColorCheckItem color="purple" />
    <Form.ColorCheckItem color="pink" />
    <Form.ColorCheckItem color="red" />
    <Form.ColorCheckItem color="orange" />
    <Form.ColorCheckItem color="yellow" />
    <Form.ColorCheckItem color="lime" />
    <Form.ColorCheckItem color="green" />
    <Form.ColorCheckItem color="teal" />
  </Form.ColorCheck>
</Form.Group>
```
