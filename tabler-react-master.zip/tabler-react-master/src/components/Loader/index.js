// @flow

import Loader from "./Loader.react";

export { Loader as default };
