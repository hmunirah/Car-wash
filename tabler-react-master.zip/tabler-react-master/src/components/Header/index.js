// @flow

import Header from "./Header.react";

export { Header as default };
