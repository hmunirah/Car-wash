// @flow

import Table from "./Table.react";

export { Table as default };
