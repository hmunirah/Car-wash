// @flow

import Dimmer from "./Dimmer.react";

export { Dimmer as default };
