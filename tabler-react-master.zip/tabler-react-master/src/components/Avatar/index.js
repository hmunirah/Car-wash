// @flow

import Avatar from "./Avatar.react";

export { Avatar as default };
