// @flow

import PricingCard from "./PricingCard.react";

export { PricingCard as default };
