```jsx
<RegisterPage />
```
