```jsx
<ForgotPasswordPage />
```
