import ForgotPasswordPage from "./ForgotPasswordPage.react";

export default ForgotPasswordPage;
