Add the Tabler RTL CSS to your project by importing the Tabler.RTL.css file instead of Tabler.css

```jsx static
import "tabler-react/dist/Tabler.RTL.css";
```
